clear;clc
close all
global  a f w b r c d D
a=0.5;
b=0.3;
w=1;
f=0.7;
D=1;
c=4;
d=1;
t=[0:0.01:100];
r=0.25;
N=[];
T=[];
while length(N)<1
[t,x]=ode45('Duffing4',t,[1 1 1 1]);
M=x(:,1)-x(:,3);
index=find(M==max(M));
if t(index)<=5
    N(1+length(N))=max(M);
    T(1+length(T))=t(index);
    y=find(N==0);
    N(y)=[];
    z=find(T==0);
    T(z)=[];
    1
else
    2
end
if length(N)==1
    break
end
end
plot(t,x(:,1)-x(:,3),'k')
k1=[0,0];
l1=[0 100];
k2=N
l2=T
hold on
plot(l1,k1,'g');
plot(l2,k2,'ok');
plot(4,0.25,'or');
plot(t,r*exp(-((t-c)/d).^2),'r')
xlabel('t');
ylabel('x1-x2');
r=0;
[t,x]=ode45('Duffing4',t,[1 1 1 1]);
MM=x(:,1)-x(:,3);
indexM=find(MM==max(MM));
MMax=max(MM)
TMM=t(indexM)
plot(t,x(:,1)-x(:,3),'b')
plot(TMM,MMax,'ob');
