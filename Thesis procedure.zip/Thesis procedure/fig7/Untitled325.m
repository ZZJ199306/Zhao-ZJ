clear;clc
close all
global  a f w b r c d D
A=[0.5 0.35];
B=[0.3 0.1];
F=[0.7 0.22];
a=A(1);
b=B(1);
f=F(1);
w=1;
D=0.001;
c=4;
d=1;
t=[0:0.01:100];
r=0.25;
N=[];
while length(N)<100
[t,x]=ode45('Duffing4',t,[1 1 1 1]);
M=x(:,1)-x(:,3);
index=find(M==max(M));
if t(index)<=5
    N(1+length(N))=max(M);
    y=find(N==0);
    N(y)=[];
    1
else
    2
end
if length(N)==100
    break
end
end
a=A(2);
b=B(2);
f=F(2);
S=[];
while length(S)<100
[t,x]=ode45('Duffing4',t,[1 1 1 1]);
M=x(:,1)-x(:,3);
index=find(M==max(M));
if t(index)<=8
    S(1+length(S))=max(M);
    y=find(S==0);
    S(y)=[];
    3
else
    4
end
if length(S)==100
    break
end
end
figure(1)
G=[0 100];
E=[2.2459,2.2459];
F=[0.19,0.19];
hold on
plot(N,'ob')
plot(S,'or')
plot(G,E,'-k')
plot(G,F,'--k')


