clear;clc
close all
global  a f w b r c d D
a=0.5;
B=[0.1:0.1:0.5];
w=1;
f=0.7;
D=0;
r=0.25;
c=4;
d=1;
t0=[0:0.01:100];
% t=[0:0.1:10];
SNR=10*log(r^2/D);
for i=1:length(B)
    figure(i)
    b=B(i);
    [t,x]=ode45('Duffing4',t0,[1 1 1 1]);
    subplot(121)
    plot(x(:,1),x(:,2),'k')
    xlabel('x');
    ylabel('y');
    subplot(122)
    plot(x(:,3),x(:,4),'k')
    xlabel('x');
    ylabel('y');
end

