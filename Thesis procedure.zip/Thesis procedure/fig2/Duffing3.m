function dx=Duffing3(t,x)
global  a f w b r c d
dx=zeros(4,1);
dx(1)=x(2);
dx(2)=-a*x(2)+x(1)-x(1)^3+b*(x(3)-x(1))+f*cos(w*t)+r*exp(-((t-c)/d).^2);
dx(3)=x(4);
dx(4)=-a*x(4)+x(3)-x(3)^3+b*(x(1)-x(3))+f*cos(w*t);