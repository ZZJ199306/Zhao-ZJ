clear;clc
close all
global  a f w b r c d
a=0.5;
b=1;
w=1;
r=0.25;
c=4;
d=1;
t0=[0:0.01:100];
for f=linspace(0,1.5,500)%r�ı仯����
    f;
 [t,x]=ode45('Duffing3',t0,[1 1 1 1]);
 Xmax=getmax(x(:,1));
 plot(f*ones(length(Xmax),1),Xmax,'k','markersize',5)
 hold on
 clear Xmax
end
xlabel('f');
ylabel('Xmax');
[l,m]=ginput(6)
% x1=[0.3798,0.3798];
% y1=[-1 2];
% x2=[0.8356,0.8356];
% y2=[-1 2];
% hold on 
% plot(x1,y1,'r')
% plot(x2,y2,'r')