function [Xmax]=getmax(x)
 a=length(x);
 j=1;
 for i=(a-1)/2:a
     b=(x(i,1)-x(i-2,1))/2;
     c=(x(i,1)+x(i-2,1))/2-x(i-1,1);
 if x(i-2,1)<=x(i-1,1)&x(i-1,1)>=x(i,1)&c==0
    Xmax(j)=x(i-1,1);
    j=j+1;
 else
 if x(i-2,1)<=x(i-1,1)&x(i-1,1)>=x(i,1)
    Xmax(j)=x(i-1,1)-b^2/(4*c);
    j=j+1;
 end
 end
 end