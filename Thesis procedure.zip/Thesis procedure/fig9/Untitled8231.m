close all
clc;clear
A=xlsread('C:\Users\Zhao Zhijie\Desktop\Thesis procedure\fig8\New Data.xlsx');%0.5 0.3 0.7
% B=[];
% C=[];
B=A(1,:);
C=A(2,:);%0.69
D=A(4,:);
E=A(5,:);%0.74
F=A(7,:);
G=A(8,:);%0.69
H=A(10,:);
I=A(11,:);%0.65
J=A(13,:);
K=A(14,:);%0.76
L=A(16,:);
M=A(17,:);%0.69
N=A(19,:);
O=A(20,:);%0.69
P=A(22,:);
Q=A(23,:);%0.69
R=A(25,:);
S=A(26,:);%0.72
T=A(28,:);
U=A(29,:);%0.7
for i=1:100
    B(i+100)=D(i);
    C(i+100)=E(i);
end
for i=1:100
    B(i+200)=F(i);
    C(i+200)=G(i);
end
for i=1:100
    B(i+300)=H(i);
    C(i+300)=I(i);
end
for i=1:100
    B(i+400)=J(i);
    C(i+400)=K(i);
end
for i=1:100
    B(i+500)=L(i);
    C(i+500)=M(i);
end
for i=1:100
    B(i+600)=N(i);
    C(i+600)=O(i);
end
for i=1:100
    B(i+700)=P(i);
    C(i+700)=Q(i);
end
for i=1:100
    B(i+800)=R(i);
    C(i+800)=S(i);
end
for i=1:100
    B(i+900)=T(i);
    C(i+900)=U(i);
end
y=find(B==0);
B(y)=[];
z=find(C==0);
C(z)=[];
x=find(C<0.5);
C(x)=[];
B(x)=[];


figure(1)
plot(B,C,'r.')
q=polyfit(B,C,6)%������Ϊ2�����������
y1=polyval(q,B);
x1=min(B):0.001:max(B);
y2=interp1(B,y1,x1,'spline'); 
p=polyfit(x1,y2,6)
hold on
plot(x1,y2,'k','linewidth',2)
ylabel('r');
xlabel('Max(x1-x2)');
R_1=[];
Error_1=[];
for i=1:length(B)
    R_1(i)=p(1)*B(i)^6+p(2)*B(i)^5+p(3)*B(i)^4+p(4)*B(i)^3+p(5)*B(i)^2+p(6)*B(i)+p(7);%10������0.5760
    Error_1(i)=(abs(( R_1(i)-C(i)))/C(i))*100;%0.63
end
figure(2)
x=find(Error_1>15);
R_2=R_1(x);
C_2=C(x);
y=find(Error_1<=15);
R_3=R_1(y);
C_3=C(y);
plot(C_2,R_2,'k.','MarkerSize',16)
hold on
plot(C_3,R_3,'r.','MarkerSize',16)
Pro=length(R_3)/length(R_1)