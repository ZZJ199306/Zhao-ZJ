clear;clc
close all
global  a f w b r c d D
a=0.5;
b=0.3;
w=1;
f=0.7;
D=1;
c=4;
d=1;
t=[0:0.01:100];
R=[0.01:0.01:1];
N=[];
S=[];
while length(N)<100
for i=1:length(R)
    r=R(i);
    [t,x]=ode45('Duffing4',t,[1 1 1 1]);
    M=x(:,1)-x(:,3);
    index=find(M==max(M));
    if t(index)<=5
        N(i+length(N))=max(M);
        S(i+length(S))=r;
        y=find(N==0);
        N(y)=[];
        z=find(S==0);
        S(z)=[];
        1
    else
        2
    end
end
if length(N)==100
    break
end
for j=1:length(S)
    x=find(R==S(j));
    R(x)=[];
end
end
% NN1=N1';0
figure(1)
plot(N,S,'or')
xlabel('Max(x1-x2)');
ylabel('r');


