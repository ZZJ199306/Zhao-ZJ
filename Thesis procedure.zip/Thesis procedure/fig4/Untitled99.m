clear;clc
close all
global  a f w b r c d D
a=0.5;
B=[0.1:0.01:0.5];
w=1;
f=0.7;
D=0;
r=0.25;
c=4;
d=1;
t0=[0:0.01:100];
% t=[0:0.1:10];
SNR=10*log(r^2/D);
for i=1:length(B)
    figure(i)
    b=B(i);
    [t,x]=ode45('Duffing4',t0,[1 1 1 1]);
    plot(t0,x(:,1)-x(:,3),'k')
    M=x(:,1)-x(:,3);
    N=max(M);
    index=find(M==N);
    k=[t0(index),t0(index)];
    l=[0 N];
    k1=[0,0];
    l1=[0 100];
    k2=N;
    l2=t0(index);
    hold on
    plot(t0,r*exp(-((t0-c)/d).^2))
    plot(k,l,'r');
    plot(l1,k1,'g');
    plot(l2,k2,'or');
    xlabel('t');
    ylabel('x1-x2');
end