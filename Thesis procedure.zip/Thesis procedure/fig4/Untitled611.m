clear;clc
close all
global  a f w b r c d D
a=0.5;
% B=[0.21 0.22 0.23 0.24 0.25 0.26 0.27 0.28 0.29 0.3 0.31 0.32];
B=[0.21 0.22 0.23 0.24 0.25 0.26 0.27 0.28 0.29 0.3 0.31 0.32];
w=1;%1
f=0.7;
D=0;
r=0.25;
c=4;
d=1;
t0=[0:0.01:100];
% t=[0:0.1:10];
figure(1)
b=B(3)
[t,x]=ode45('Duffing4',t0,[1 1 1 1]);
plot(t0,x(:,1)-x(:,3),'k')
M=x(:,1)-x(:,3);
N=max(M)
index=find(M==N);
k=[t0(index),t0(index)];
l=[0 N];
k1=[0,0];
l1=[0 100];
k2=N;
l_1=t0(index)
hold on
% plot(k,l,'r');
plot(l1,k1,'g');
plot(l_1,k2,'or');
plot(t0,r*exp(-((t0-c)/d).^2))
p=[c,c];
q=[0 r];
plot(c,r,'ob')
% plot(p,q,'b')
title('k=0.21,(t,MAX(x1-x2))=(13.7600,0.7087)')
xlabel('t');
ylabel('x1(t)-x2(t)');
figure(2)
plot(x(:,1),x(:,2),'k')