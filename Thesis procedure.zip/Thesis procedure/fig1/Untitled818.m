close all
clc;clear
A=xlsread('C:\Users\Zhao Zhijie\Desktop\Thesis procedure\fig1\Test8188.xlsx');%0.5 0.3 0.7
B=A(2:end,1);
C=1:1:length(B);
D=A(2:end,2);%0.69
figure(1)
plot(C,D,'k')
axis([0 23701 0.02 0.04])
E=xlsread('C:\Users\Zhao Zhijie\Desktop\Thesis procedure\fig1\Test8186.xlsx');%0.5 0.3 0.7
F=E(2:end,1);
G=1:1:length(F);
H=E(2:end,2);%0.69
figure(2)
plot(G,H,'k')